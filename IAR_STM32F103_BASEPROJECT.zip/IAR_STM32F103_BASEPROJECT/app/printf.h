#ifndef __PRINTF__H
#define __PRINTF__H

void PrintfInit();

#endif